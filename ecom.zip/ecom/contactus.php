<?php
require ("includes/common.php");
?> 
<html>
    <head>
        <title>contact_us</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


    
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
         <link href="contact.css" rel="stylesheet" type="text/css">
    </head>
    <body>
       <?php
       include 'includes/header.php';?>
        <br><br>
        
        <div class="container">
        <h2>LIVE SUPPORT</h2>
        <p>24 Hours | 7 Days a week | 365 days a year Live Technical Support</p>
   
        
        
        <h3>Contact Us</h3>
        
         <form action="POST">
                            <div class="form-group">
                                name:<br>
                                <input class="form-control"  name="name"  required = "true" pattern="^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$">
                            </div>
                            <div class="form-group">
                                email:<br>
                                <input type="email" class="form-control"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"  name="e-mail" required = "true"> 
                            </div>
                            <div class="form-group">
                                Message:<br>
                                <textarea name="textarea"
                                     rows="5" cols="40" class="form-control" ></textarea>
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                        </form>
        <br><br>
        
 </div>
        
        
        
       
               
     <footer class="footer navbar-fixed-bottom">
         <div class="container">
             <center>
                 <h4>Contacts</h4>
                  <dl>
  <dt><span class="glyphicon glyphicon-phone"></span>Phone</a></li></dt>
  <dd>+91 900000 00000 </dd>
  <dt><span class="glyphicon glyphicon-inbox"></span>Email</dt>
  <dd>- myinfo@gmail.com</dd>

</dl>
                 
             </center>          
          </div>
     </footer> 
         <br><br><br>
        
        
       
    </body>
    
    
</html>
