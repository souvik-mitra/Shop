<?php
session_start();
if(!isset($_SESSION['email']));
{
    echo $var  = "<script> location.replace('login.php'); </script>";
}
session_destroy();

echo $var  = "<script> location.replace('index.php'); </script>";

?>