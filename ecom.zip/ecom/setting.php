<?php
require_once("includes/common.php");
if (!isset($_SESSION['email'])) {
    echo $var  = "<script> location.replace('login.php'); </script>";
}
?>


<html>
    <head>
        
        <title>setting</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


    
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
         <link href="setting.css" rel="stylesheet" type="text/css">
    </head>
    <body>
    <?php include 'includes/header.php'; ?>
        
   <div class="container-fluid" id="content">
            <div class="row">
                <div class="col-lg-4 col-lg-offset-4" id="settings-container">
                    <h4>Change Password</h4>
                    <form role="form" action="" method="POST"><!--we will use on submit trigger to get n send data from same page -->
                        <div class="form-group">
                            <input type="password" class="form-control" name="old_password"  placeholder="Old Password" required = "true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="New Password" required = "true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="passwordc"  placeholder="Re-type New Password" required = "true">
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Change</button>
                        
                    </form>
                </div>
            </div>
        </div>        
        <?php 
         if (isset($_POST['submit'])) {
        $old_pass = filter_var($_GET['old_password'],FILTER_SANITIZE_STRING);
        $old_pass = MD5($old_pass);
        $new_pass = filter_var($_POST['password'],FILTER_SANITIZE_STRING);
        $new_pass = MD5($new_pass);
        $new_pass1 = filter_var($_POST['passwordc'],FILTER_SANITIZE_STRING);
        $new_pass1 = MD5($new_pass1);
        $email = $_SESSION['email'];
        $query = "SELECT email, password FROM users WHERE email ='$email'";
        
        $result = mysqli_query($con, $query);
        $row = mysqli_fetch_array($result);
        $orig_pass = $row['password'];
        
        if ($new_pass != $new_pass1) {
            echo $var  = "<script> alert('two password doesnt match'); </script>";
        } else {
            if ($old_pass == $orig_pass) {
                $email = $_SESSION['email'];
                $query = "UPDATE  users SET password = '$new_pass' WHERE email = '$email'";
                $result = mysqli_query($con, $query);
              //  header('location: setting.php?error=Password Updated');
              echo $var  = "<script> alert('Password updated'); </script>";
            } else{
              //  header('location: setting.php?error=Wrong Old Password');
              echo $var  = "<script> alert('Wrong old password'); </script>";
        }}
    }
        ?>
        
        
       
     <footer class="footer navbar-fixed-bottom">
         <div class="container">
          <center><p>Copyright © Lifestyle Store. All Rights Reserved | Contact Us: +91 900000 00000 </p></center>          
          </div>
     </footer>     
        
                
    </body>
    
</html>
