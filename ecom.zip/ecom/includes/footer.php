<html>
    <head><style>
        footer
    {
      padding:10px 0;
      background-color:#101010;
      color:#9d9d9d;
      bottom:0;
      width:100%;
    }
    </style>
    </head>
    <body>
 <footer class="footer navbar-fixed-bottom">
         <div class="container">
          <center>
            <center><p>Copyright © Lifestyle Store. All Rights Reserved | Contact Us: +91 900000 00000 </p></center> 
               For Further more details <a href="contactus.php">Contact Us</a>
          
           </center>
              
     </footer> 
        </body>
</html>
